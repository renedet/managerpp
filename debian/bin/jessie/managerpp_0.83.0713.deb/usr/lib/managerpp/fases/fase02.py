#!/usr/bin/python

# toma tempo para simular processamento

import time
time.sleep(60)
